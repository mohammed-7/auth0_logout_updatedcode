import React, { Component } from 'react';

class Github extends Component {
    render() {
        return (
            <div>
                I am coming from git...!
            </div>
        );
    }
}

export default Github;